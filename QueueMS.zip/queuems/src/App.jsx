import React, { useState } from "react";
import "./App.css";

const queueData = [
  { token: "A024", patient: "Patient A024", department: "Outpatient", status: "Serving", wait: "Now" },
  { token: "A025", patient: "Patient A025", department: "Consultation", status: "Waiting", wait: "5 min" },
  { token: "A026", patient: "Patient A026", department: "Laboratory", status: "Waiting", wait: "12 min" },
  { token: "A027", patient: "Patient A027", department: "Pharmacy", status: "Waiting", wait: "18 min" },
];

const navItems = [
  ["Home", "#home"],
  ["About", "#about"],
  ["Features", "#features"],
  ["Queue Display", "#queue"],
  ["Contact", "#contact"],
];

const features = [
  ["01", "Reception & Registration", "Register patients, generate queue tokens and direct patients to the right department.", "♙"],
  ["02", "Live Queue Management", "Call the next patient, update queue status and reduce confusion at busy service points.", "↗"],
  ["03", "Room & Provider Panels", "Let staff manage their assigned queues and call patients into consultation rooms.", "✚"],
  ["04", "Public Queue Display", "Show currently serving tokens and upcoming patients on waiting-room screens.", "▣"],
  ["05", "Reports & Analytics", "Track waiting times, patient throughput and department performance.", "▥"],
  ["06", "Role-Based Access", "Give administrators, receptionists and healthcare staff appropriate permissions.", "◇"],
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("All");

  const visibleQueue = queueData.filter((item) => {
    return activeTab === "All" || item.status === activeTab;
  });

  return (
    <main>
      <section className="hero" id="home">
        <div className="hero-image" />
        <div className="hero-overlay" />
        <div className="wave wave-one" />
        <div className="wave wave-two" />

        <header className="navbar">
          <a className="brand" href="#home" aria-label="AfriQueue home">
            <span className="brand-mark">A</span>
            <span>Afri<span className="brand-accent">Queue</span></span>
          </a>

          <nav className={menuOpen ? "nav-links open" : "nav-links"}>
            {navItems.map(([label, href], index) => (
              <a
                key={href}
                className={index === 0 ? "nav-active" : ""}
                href={href}
                onClick={() => setMenuOpen(false)}
              >
                {label}
              </a>
            ))}
          </nav>

          <button
            className="menu-toggle"
            aria-label="Toggle navigation"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? "✕" : "☰"}
          </button>
        </header>

        <div className="hero-content">
          <div className="hero-copy">
            <span className="eyebrow">
              <span className="status-dot" /> SMART HEALTHCARE TECHNOLOGY
            </span>

            <h1>Less waiting.<br />Better care.</h1>

            <p>
              A smarter way to manage patient queues, streamline hospital
              operations, and deliver a better healthcare experience.
            </p>

            <div className="hero-actions">
              <a className="button button-primary" href="#queue">
                EXPLORE THE PLATFORM <span>↗</span>
              </a>
              <a className="button button-ghost" href="#features">
                DISCOVER FEATURES
              </a>
            </div>

            <div className="trust-line">
              <span className="trust-icon">✚</span>
              Built for modern healthcare facilities
            </div>
          </div>

          <div className="hero-display">
            <span className="display-label">PATIENT FLOW / LIVE PREVIEW</span>
            <h2>CARE<br />FLOWS<br /><span>BETTER.</span></h2>

            <div className="floating-token">
              <span className="token-icon">✚</span>
              <div>
                <small>NOW SERVING</small>
                <strong>A024</strong>
              </div>
              <span className="live-badge">LIVE</span>
            </div>
          </div>
        </div>

        <div className="hero-bottom">
          <div className="metric-card">
            <span className="metric-icon">♙</span>
            <div>
              <small>NOW SERVING</small>
              <strong>A024</strong>
            </div>
          </div>
          <div className="metric-card">
            <span className="metric-icon">◷</span>
            <div>
              <small>IN THE QUEUE</small>
              <strong>08 <em>patients</em></strong>
            </div>
          </div>
          <div className="metric-card">
            <span className="metric-icon">◴</span>
            <div>
              <small>AVERAGE WAIT</small>
              <strong>12 <em>min</em></strong>
            </div>
          </div>

          <div className="slide-count">
            <strong>01</strong><span>/ 03</span><i />
          </div>
        </div>
      </section>

      <section className="intro-section" id="about">
        <div>
          <span className="section-kicker">A BETTER PATIENT EXPERIENCE</span>
          <h2>Every patient matters.<br /><span>Every minute counts.</span></h2>
        </div>
        <p>
          AfriQueue helps healthcare teams coordinate patient flow from
          reception to consultation, laboratory and pharmacy — all from
          one connected platform.
        </p>
      </section>

      <section className="features-section" id="features">
        <div className="section-heading">
          <div>
            <span className="section-kicker">ONE CONNECTED PLATFORM</span>
            <h2>Designed for the way<br />hospitals work.</h2>
          </div>
          <p>Less manual coordination. More visibility. Smoother service.</p>
        </div>

        <div className="feature-grid">
          {features.map(([number, title, description, icon]) => (
            <article className="feature-card" key={number}>
              <div className="feature-top">
                <span className="feature-icon">{icon}</span>
                <span className="feature-number">{number}</span>
              </div>
              <h3>{title}</h3>
              <p>{description}</p>
              <a href="#queue" aria-label={`Explore ${title}`}>EXPLORE MODULE ↗</a>
            </article>
          ))}
        </div>
      </section>

      <section className="queue-section" id="queue">
        <div className="queue-heading">
          <div>
            <span className="section-kicker">QUEUE MONITOR</span>
            <h2>Patient flow at a glance.</h2>
            <p>Sample preview data — not connected to a hospital server.</p>
          </div>
          <span className="demo-badge"><span /> DEMO PREVIEW</span>
        </div>

        <div className="queue-panel">
          <div className="queue-toolbar">
            <strong>Today's queue</strong>
            <div className="queue-tabs">
              {["All", "Serving", "Waiting"].map((tab) => (
                <button
                  key={tab}
                  className={activeTab === tab ? "tab active" : "tab"}
                  onClick={() => setActiveTab(tab)}
                >
                  {tab}
                </button>
              ))}
            </div>
          </div>

          <div className="queue-table-wrap">
            <table className="queue-table">
              <thead>
                <tr>
                  <th>QUEUE TOKEN</th>
                  <th>PATIENT REFERENCE</th>
                  <th>DEPARTMENT</th>
                  <th>STATUS</th>
                  <th>EST. WAIT</th>
                </tr>
              </thead>
              <tbody>
                {visibleQueue.map((item) => (
                  <tr key={item.token}>
                    <td><strong className="token-text">{item.token}</strong></td>
                    <td>{item.patient}</td>
                    <td>{item.department}</td>
                    <td>
                      <span className={`queue-status ${item.status.toLowerCase()}`}>
                        {item.status}
                      </span>
                    </td>
                    <td>{item.wait}</td>
                  </tr>
                ))}
                {visibleQueue.length === 0 && (
                  <tr><td colSpan={5}>No queue records found.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>

      <section className="contact-section" id="contact">
        <div>
          <span className="section-kicker">READY TO IMPROVE YOUR QUEUE?</span>
          <h2>Let patient care<br />flow better.</h2>
          <p>Bring your reception, service points and waiting-room displays together.</p>
        </div>
        <a className="button button-primary" href="mailto:contact@afriqueue.com">
          TALK TO AFRIQUEUE <span>↗</span>
        </a>
      </section>

      <footer className="footer">
        <a className="brand" href="#home">
          <span className="brand-mark">A</span>
          <span>Afri<span className="brand-accent">Queue</span></span>
        </a>
        <p>Powered by Intelligence. Driven by Service.</p>
        <span>© {new Date().getFullYear()} AfriQueue Technologies Ltd.</span>
      </footer>
    </main>
  );
}

export default App;
